#Hamza Aamoud
#2/18/2024
#P1HW1
#Taking multiple user inputs to do math

num1 = int(input("Enter an integer"))
num1square = num1**2
num1cube = num1**3
print("You entered:",num1)
print(num1,"squared is",num1square)
print("And",num1,"cubed is",num1cube)
num2 = int(input("Enter another integer"))
numsum = num1 + num2
numprod = num1 * num2
print(num1,"+",num2,"is",numsum)
print(num1,"*",num2,"is",numprod)